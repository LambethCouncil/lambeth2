<?php
?>
<div class="panels-dashboard">
  <div class="dashboard-left clear-block">
    <?php print $left; ?>
  </div>

  <div class="dashboard-right clear-block">
    <?php print $right; ?>
  </div>
</div>
